export class DetailProduit {
  idDetailProduit: number;
  dateCeation: Date;
  dateDerniereModification: Date;
  categorieProduit: string;
}
