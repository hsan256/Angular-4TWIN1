import { Produit } from "./produit";

export class DetailProduit {
  idDetailProduit: number;
  datecreation: Date;
  dateDernierModification: Date;
  categorieProduit: string;
  produit :Produit;
}
