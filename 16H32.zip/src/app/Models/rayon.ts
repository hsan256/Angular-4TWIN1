export class Rayon {
    idRayon: number;
    codeRayon: string;
    libelleRayon: string;

    constructor(idRayon?: number, codeRayon?:string, libelleRayon?:string){
        this.idRayon = idRayon;
        this.codeRayon = codeRayon;
        this.libelleRayon = libelleRayon;
    }
}