import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-rayons',
  templateUrl: './all-rayons.component.html',
  styleUrls: ['./all-rayons.component.css']
})
export class AllRayonsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
