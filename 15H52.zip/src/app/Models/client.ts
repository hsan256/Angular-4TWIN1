export class Client {
    idClient : number;
    nom:string;
    prenom:string;
    email:string;
    password:string;
    dateNaissance:Date;
    categorieClient:String;
    profession:string;
    }